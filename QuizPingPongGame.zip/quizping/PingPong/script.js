"use strict";
var firstrod = document.getElementById("firstrodd");
var secondrod = document.getElementById("secondrodd");
var balls = document.getElementById("ballmove");
var timeoutrun= false;
var current_score =
{
    first: 0,
    second: 0,
}
var action =
{
    lossside: "",
    lostt: false
}
function elecenter(element)
{
    element.style.left = ((document.documentElement.clientWidth / 2) - (element.offsetWidth / 2)).toString() + "px";
    element.style.left = ((document.documentElement.clientWidth / 2) - (element.offsetWidth / 2)).toString() + "px";
    if (element == balls)
    {
        if (action.lostt)
        {
            if (action.lossside == "first")
            {
                balls.style.top = (firstrod.clientHeight+5).toString() + "px";
            }
            else
            {
                balls.style.top = (document.documentElement.clientHeight - secondrod.clientHeight - balls.clientHeight-5).toString() + "px";
            }
        }
        else
            element.style.top = (document.documentElement.clientHeight / 2).toString() + "px";
    }
}

function addingevent()
{
    window.addEventListener("keydown", function (event)
    {
        let code = event.keyCode;
        if (code == 68)
        {

            let left_numeric = parseInt(
                firstrod.style.left.substring(0, firstrod.style.left.length - 2)
            );
            left_numeric += 20;
            if (left_numeric + firstrod.offsetWidth > document.documentElement.clientWidth)
            {
                left_numeric = document.documentElement.clientWidth - firstrod.offsetWidth;
            }
            firstrod.style.left = left_numeric.toString() + "px";
            secondrod.style.left = left_numeric.toString() + "px";
        } else if (code == 65)
        {
            let left_numeric = parseInt(
                firstrod.style.left.substring(0, firstrod.style.left.length - 2)
            );
            left_numeric -= 20;
            if (left_numeric < 0)
            {
                left_numeric = 0;
            }
            firstrod.style.left = left_numeric.toString() + "px";
            secondrod.style.left = left_numeric.toString() + "px";
        }
    });
}
function upperbartouching()
{
    let ball_top_numerical = balls.getBoundingClientRect().top;
    let ball_left_numerical = balls.getBoundingClientRect().left;
    let bar_left_numerical = parseInt(firstrod.style.left.substring(0, firstrod.style.left.length - 2));
    if ((ball_top_numerical <= firstrod.clientHeight) && (ball_left_numerical + (balls.clientWidth / 2) > bar_left_numerical) && (ball_left_numerical + (balls.clientWidth / 2) < bar_left_numerical + firstrod.clientWidth))
    {
        if (!current_timeout_is_running)
        {
            timeoutrun= true;
            setTimeout(function ()
            {
                current_score.first++;
                timeoutrun= false;
                console.log("first", current_score.first);
            }, 200);
        }
        return true;
    }
    return false;
}
function lowbartouching()
{
    let ball_top_numerical = balls.getBoundingClientRect().top;
    let ball_left_numerical = balls.getBoundingClientRect().left;
    let bar_left_numerical = parseInt(secondrod.style.left.substring(0, secondrod.style.left.length - 2));
    if ((ball_top_numerical + balls.clientHeight + secondrod.clientHeight >= document.documentElement.clientHeight) && (ball_left_numerical + (balls.clientWidth / 2) > bar_left_numerical) && (ball_left_numerical + (balls.clientWidth / 2) < bar_left_numerical + secondrod.clientWidth))
    {
        if (!current_timeout_is_running)
        {
            timeoutrun= true;
            setTimeout(function ()
            {
                current_score.second++;
                timeoutrun= false;
                console.log("second", current_score.second);
            }, 200);
        }
        return true;
    }
    return false;
}
function ballinterval()
{

    let interval_id = setInterval(function ()
    {
        let numeric_left = balls.getBoundingClientRect().left;
        let numeric_top = balls.getBoundingClientRect().top;
        if (numeric_left <= 0)
        {
            let class_present = balls.classList[0];
            if (class_present == "topleft")
            {
                balls.classList.remove(class_present);
                balls.classList.add("topright");
            }
            else if (class_present == "bottomleft")
            {
                balls.classList.remove(class_present);
                balls.classList.add("bottomright");
            }
        }
        else if (numeric_left + balls.offsetWidth >= document.documentElement.clientWidth)
        {
            let class_present = balls.classList[0];
            if (class_present == "topright")
            {
                balls.classList.remove(class_present);
                balls.classList.add("topleft");
            }
            else if (class_present == "bottomright")
            {
                balls.classList.remove(class_present);
                balls.classList.add("bottomleft");
            }
        }
        else if (numeric_top <= 0 || numeric_top + balls.offsetHeight >= document.documentElement.clientHeight)
        {
            balls.classList.remove(balls.classList[0])
            if (numeric_top <= 0)
            {
                action.lossside = "first";
                action.lostt = true;
            }
            else if (numeric_top + balls.offsetHeight >= document.documentElement.clientHeight)
            {
                action.lossside = "second";
                action.lostt = true;
            }
            elecenter(balls);
            elecenter(firstrod);
            elecenter(secondrod);

            alert('Game Over');
            clearInterval(interval_id);
            if (current_score.first > localStorage.getItem('first'))
            {
                localStorage.setItem('first', current_score.first);
            }
            if (current_score.second > localStorage.getItem('second'))
            {
                localStorage.setItem('second', current_score.second);
            }
            current_score.first=0;
            current_score.second=0;
            scoredisplay();
        }
        else if (lowbartouching())
        {
            let class_present = balls.classList[0];
            if (class_present == "bottomright")
            {
                balls.classList.remove(class_present);
                balls.classList.add("topright");
            }
            else if (class_present == "bottomleft")
            {
                balls.classList.remove(class_present);
                balls.classList.add("topleft");
            }
        }
        else if (upperbartouching())
        {
            let class_present = balls.classList[0];
            if (class_present == "topright")
            {
                balls.classList.remove(class_present);
                balls.classList.add("bottomright");
            }
            else if (class_present == "topleft")
            {
                balls.classList.remove(class_present);
                balls.classList.add("bottomleft");
            }
        }
    }, 1)
}
function scoredisplay()
{
    if (localStorage.getItem('first') == null)
    {
        localStorage.setItem('first', 0);
        localStorage.setItem('second', 0);
        window.alert("It is first time");
    }
    else
    {
        window.alert("First rod has a maximum score of " + localStorage.getItem('first').toString() + "\n" + "Second rod has a maximum score of " + localStorage.getItem('second'));
    }
}

elecenter(firstrod);
elecenter(secondrod);
elecenter(balls);
scoredisplay();
addingevent();
ballinterval();

document.addEventListener('keydown', function (event)
{
    if (event.keyCode == 13)
    {
        if (action.lostt)
        {
            if (action.lossside == "first")
            {
                balls.classList.add('bottomright');
            }
            else
            {
                balls.classList.add('topright');
            }
        }
        else
            balls.classList.add('bottomright');
        ballinterval()
    }
})


