import java.util.Scanner;
import java.util.Arrays;;
class Minmax{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
      System.out.print("Enter the array size:");
      int n=sc.nextInt();
      int a[]=new int[n];
      int sum=0;
      System.out.println("Enter the array elements:");
      for(int i=0; i<n; i++){
        a[i]=sc.nextInt();
        sum+=a[i];
      }
      Arrays.sort(a);
      System.out.println("1.The element with the Minimum value: "+a[0]);
      System.out.println("2.The element with the Maximum value: "+a[n-1]);
      System.out.println("3.The average of all array elements: "+sum/n);
      System.out.println("4.Total number of array elements: "+n);
    }
}