import java.util.Scanner;
import java.util.Arrays;
class Onestoend{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the array size:");
        int n=sc.nextInt();
        int a[]=new int[n];
        int c=0,j=0;
        System.out.println("Enter the array elements:");
        for(int i=0; i<n; i++){
            int temp=sc.nextInt();
            if(temp==1){
                c+=1;
            }
            else{
          a[j]=temp;
          j+=1;
            }
        }
        System.out.println("Array elements after moving Ones to end: ");
        for(int i=0; i<c; i++){
            a[j]=1;
            j+=1;
        }
        for(int i=0; i<n; i++){
            System.out.print(a[i]+",");
        }
    }
}