import React from "react";
import '../App.css';
import { Container, Row, Col, Form, Button } from 'react-bootstrap';
import './Contact.css';

const Login = () => {

  const inputStyle = {
    padding: "10px",
    border: "none",
    borderRadius: "5px",
    marginBottom: "15px",
    width: "100%",
  };

  return (
    <div>
      <div>
        <Container fluid>
          <Row>         
            <Col md={4} id='math'>
              <div className="card">
                <div className="card-body">
                <h1 className="title">Login</h1>
                  <Form>
                    <Form.Group controlId="formBasicName">
                      <Form.Label>Username</Form.Label>
                      <Form.Control type="text" placeholder="Enter your Username" style={inputStyle} />
                    </Form.Group>

                    <Form.Group>
                      <Form.Label>Password</Form.Label>
                      <Form.Control type="email" placeholder="Enter Password" style={inputStyle} />
                    </Form.Group>

                    <Button variant="primary" type="submit" className='btn'>
                      Login
                    </Button>
                  </Form>
                </div>
              </div>
            </Col>
          </Row>
        </Container>
        <div></div>
      </div>
    </div>
  );
}

export default Login;