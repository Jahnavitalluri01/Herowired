import React from "react";
import '../App.css';
import { Container, Row, Col, Form, Button } from 'react-bootstrap';
import './Contact.css';

const Contact = () => {

  const inputStyle = {
    padding: "10px",
    border: "none",
    borderRadius: "5px",
    marginBottom: "15px",
    width: "100%",
  };

  return (
    <div>
      <div>
        <Container fluid>
          <Row>
         
            <Col md={4} id='math' >
              <div className="card">
                <div className="card-body">
                <h1 className="title">Contact Us</h1>
                  <Form>
                    <Form.Group controlId="formBasicName">
                      <Form.Label>Name</Form.Label>
                      <Form.Control type="text" placeholder="Enter your name" style={inputStyle} />
                    </Form.Group>

                    <Form.Group controlId="formBasicEmail">
                      <Form.Label>Email address</Form.Label>
                      <Form.Control type="email" placeholder="Enter email" style={inputStyle} />
                    </Form.Group>

                    <Form.Group controlId="formBasicMessage">
                      <Form.Label>Message</Form.Label>
                      <Form.Control as="textarea" rows={5} placeholder="Enter your message" style={inputStyle} />
                    </Form.Group>

                    <Button variant="primary" type="submit" className='btn'>
                      Submit
                    </Button>
                  </Form>
                </div>
              </div>
            </Col>
          </Row>
        </Container>
        <div></div>
      </div>
    </div>
  );
}

export default Contact;