import React, { useState, useEffect} from "react";
import pic1 from '../images/pic1.png';
import pic3 from '../images/pic2.png'
import pic4 from '../images/pic3.png'
import { Link } from 'react-router-dom';
import '../App.css';
import { Container, Row, Col, Form, Button, Nav, Navbar } from 'react-bootstrap';
const Home=()=>{
    const imgCon = [pic1,pic4,pic1,pic4,pic1];
    let [index,setindex] = useState(0)

    useEffect(() => {
        const imageChange = setInterval(() => {
           index++;
            if(index > 3)
               index = 0;
          setindex(index);
        }, 1000);
        return () => clearInterval(imageChange);
      }, []);
    return(
        <>
<div id='cent'>
    <h1>Home</h1>
    <div id='smal'>
        <img src={imgCon[index]} alt=""/>
        <img src={imgCon[index+1]} alt=""/>
        
        
        </div>


    <button type="submit" className='btn'><Link to ='/Resume'>Create a Resume</Link></button>
    </div>
   
    </>

    )
}
export default Home;