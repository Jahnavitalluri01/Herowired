import './App.css';
import {Routes,Route} from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
import Navigation from './components/Navigation';
import Footer from './components/Footer';
import Resume from './components/Resume';
import PdfComponent from './components/PdfComponent';
import Home from './components/home';
import Contact from './components/contact';
import Login from './components/login';


function App() {
  return (
    <Container fluid className="bg-white p-0">

      <Navigation></Navigation>

      <Routes>
        <Route path='/' element={<Home/>} > </Route>    
        <Route path='/Login' element={<Login/>} > </Route>    
        <Route path='/Contact' element={<Contact/>} > </Route>    
        <Route path="/Resume" element={ <Resume/> } exact></Route>
        <Route path="/preview" element={<PdfComponent/>}></Route>
      </Routes>
      
      <Footer></Footer>

    </Container>
  );
}

export default App;
