import java.util.*;
import java.io.*;
public class Reading {
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        try{
            File f1=new File("input.txt");
            FileInputStream fi=new FileInputStream(f1);
            BufferedReader br=new BufferedReader(new InputStreamReader(fi));
            String Line;
            int k=0;
            while((Line=br.readLine())!=null)
            {
                if(Line=="")
                {
                    k+=1;
                }
                k+=Line.length();
            }
            System.out.println(k);
            br.close();
            fi.close();
        }
        catch(IOException e)
        {
            System.err.println("Error: "+e.getMessage());
        }
    }
}

