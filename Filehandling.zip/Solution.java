import java.io.*;
import java.util.*;
public class Solution {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        try{
            int a=sc.nextInt();
            int b=sc.nextInt();
            int div=a/b;
            System.out.println(div);
        }
        catch(ArithmeticException e1){
            System.out.println(e1);
        }
        catch(InputMismatchException e2){
            System.out.println("java.util.InputMismatchException");
        }
    }
}

