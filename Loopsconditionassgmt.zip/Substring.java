import java.util.*;
class Substring
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter String ");
        String s=sc.nextLine();
        int a,b;
        System.out.println("Enter values of starting and ending index: ");
        a=sc.nextInt();
        b=sc.nextInt();
        System.out.print(s.substring(a,b));

    }
}