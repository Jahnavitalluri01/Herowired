import java.util.Scanner;
public class Evenodd {
    public static void main(String[] args) {
        System.out.println("Menu based app - Even/Odd Checker");
        Scanner sc=new Scanner(System.in);
        char s='y';
        while(s=='y' || s=='Y'){
        System.out.println("Please enter the number");
        int n=sc.nextInt();
        if(n%2==0){
            System.out.println("The given number "+n+" is a EVEN number");
        }
        else{
            System.out.println("The given number "+n+" is an ODD number");
        }
        System.out.println("Do you want to continue");
        s=sc.next().charAt(0);
    }
    }
}
